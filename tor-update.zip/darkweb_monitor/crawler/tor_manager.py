"""Built-in Tor: start, watch and stop a tor process that runs in the background.

The release bundles ship the official Tor Expert Bundle in ``tor/`` next to the
executable. ``TOR_MANAGED`` decides what happens:

* ``auto``   - (default) on start-up use a Tor that is already listening (system
               service on 9050 or Tor Browser on 9150); otherwise start the bundled one.
* ``manual`` - start only when the user presses "Connect to Tor" in the dashboard.
* ``never``  - never start a tor process (use your own Tor).

The control port is protected with a random password that only lives in memory.
"""
from __future__ import annotations

import logging
import os
import re
import secrets
import shutil
import socket
import subprocess
import sys
import threading
import time
from collections import deque
from pathlib import Path
from typing import Optional

from config.settings import BASE_DIR, DATA_DIR, settings

logger = logging.getLogger(__name__)

EXE = "tor.exe" if os.name == "nt" else "tor"
TOR_BROWSER_PORT = 9150
_BOOT = re.compile(r"Bootstrapped (\d+)%(?: \(([^)]*)\))?:? ?(.*)")


def _port_open(port: int, host: Optional[str] = None, timeout: float = 0.5) -> bool:
    try:
        with socket.create_connection((host or settings.TOR_PROXY_HOST, port), timeout=timeout):
            return True
    except OSError:
        return False


def find_binary() -> Optional[Path]:
    """Bundled tor first, then TOR_BINARY, then PATH."""
    roots = [BASE_DIR, Path(getattr(sys, "_MEIPASS", BASE_DIR)), Path(sys.executable).resolve().parent]
    candidates: list[Path] = []
    if settings.TOR_BINARY:
        candidates.append(Path(settings.TOR_BINARY).expanduser())
    for r in roots:
        candidates += [r / "tor" / "tor" / EXE, r / "tor" / EXE]
    for c in candidates:
        if c.is_file():
            return c
    found = shutil.which("tor")
    return Path(found) if found else None


def _is_bundled(binary: Path) -> bool:
    for root in (BASE_DIR, Path(getattr(sys, "_MEIPASS", BASE_DIR))):
        try:
            binary.resolve().relative_to((root / "tor").resolve())
            return True
        except ValueError:
            continue
    return False


class TorManager:
    def __init__(self) -> None:
        self.proc: Optional[subprocess.Popen] = None
        self.progress = 0
        self.phase = ""
        self.error: Optional[str] = None
        self.started_at: Optional[float] = None
        self.log: deque[str] = deque(maxlen=60)
        self.mode = "idle"  # idle | starting | ready | external | stopped | error
        self._lock = threading.Lock()
        self._ready = threading.Event()

    # ------------------------------------------------------------------ status
    @property
    def running(self) -> bool:
        return self.proc is not None and self.proc.poll() is None

    def status(self) -> dict:
        b = find_binary()
        return {"mode": self.mode, "managed": settings.TOR_MANAGED, "running": self.running,
                "progress": self.progress, "phase": self.phase, "error": self.error,
                "binary": str(b) if b else None, "bundled": bool(b and _is_bundled(b)),
                "pid": self.proc.pid if self.running else None, "log": list(self.log)[-12:]}

    # ------------------------------------------------------------------- start
    def _adopt_external(self) -> bool:
        """Use a Tor that is already listening (system service or Tor Browser)."""
        if _port_open(settings.TOR_PROXY_PORT):
            self.mode, self.progress, self.phase, self.error = "external", 100, "existing Tor", None
            self._ready.set()
            return True
        if settings.TOR_PROXY_PORT != TOR_BROWSER_PORT and _port_open(TOR_BROWSER_PORT):
            logger.info("Tor Browser detected on %d - using it", TOR_BROWSER_PORT)
            settings.TOR_PROXY_PORT = TOR_BROWSER_PORT
            self.mode, self.progress, self.phase, self.error = "external", 100, "Tor Browser", None
            self._ready.set()
            return True
        return False

    def start(self, adopt: bool = True) -> dict:
        """Connect to Tor: reuse a running one or start the bundled tor in the background."""
        with self._lock:
            if self.running:
                return self.status()
            if adopt and self._adopt_external():
                self._invalidate()
                return self.status()
            binary = find_binary()
            if not binary:
                self.mode = "error"
                self.error = ("Tor was not found. The release bundles include it in the 'tor' folder; "
                              "otherwise install Tor or start Tor Browser.")
                return self.status()
            if _port_open(settings.TOR_PROXY_PORT):
                self.mode, self.error = "error", f"port {settings.TOR_PROXY_PORT} is used by another program"
                return self.status()
            try:
                self._launch(binary)
            except Exception as e:  # noqa: BLE001
                self.mode, self.error = "error", f"could not start tor: {e}"
                logger.exception("tor start failed")
            return self.status()

    def _env(self, binary: Path) -> dict:
        env = dict(os.environ)
        libdir = str(binary.parent)
        if sys.platform.startswith("linux"):
            env["LD_LIBRARY_PATH"] = libdir + os.pathsep + env.get("LD_LIBRARY_PATH", "")
        elif sys.platform == "darwin":
            env["DYLD_LIBRARY_PATH"] = libdir + os.pathsep + env.get("DYLD_LIBRARY_PATH", "")
        return env

    def _hash_password(self, binary: Path, password: str) -> Optional[str]:
        try:
            out = subprocess.run([str(binary), "--quiet", "--hash-password", password], capture_output=True,
                                 text=True, timeout=30, env=self._env(binary), **self._popen_flags())
            line = [x for x in out.stdout.splitlines() if x.startswith("16:")]
            return line[-1].strip() if line else None
        except Exception:  # noqa: BLE001
            return None

    @staticmethod
    def _popen_flags() -> dict:
        if os.name == "nt":
            return {"creationflags": getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)}
        return {}

    def _torrc(self, binary: Path) -> Path:
        data = DATA_DIR / "tor"
        data.mkdir(parents=True, exist_ok=True)
        lines = [f"SocksPort {settings.TOR_PROXY_HOST}:{settings.TOR_PROXY_PORT}",
                 f"DataDirectory {data.as_posix()}", "ClientOnly 1", "AvoidDiskWrites 1", "Log notice stdout",
                 f"__OwningControllerProcess {os.getpid()}"]  # tor exits if this app dies or is closed
        if not _port_open(settings.TOR_CONTROL_PORT):
            password = settings.TOR_CONTROL_PASSWORD or secrets.token_urlsafe(24)
            hashed = self._hash_password(binary, password)
            if hashed:
                lines += [f"ControlPort {settings.TOR_PROXY_HOST}:{settings.TOR_CONTROL_PORT}",
                          f"HashedControlPassword {hashed}"]
                settings.TOR_CONTROL_PASSWORD = password  # in memory only, used by "New circuit"
        for root in (binary.parent.parent / "data", binary.parent / "data"):
            if (root / "geoip").is_file():
                lines += [f"GeoIPFile {(root / 'geoip').as_posix()}", f"GeoIPv6File {(root / 'geoip6').as_posix()}"]
                break
        rc = data / "torrc"
        rc.write_text("\n".join(lines) + "\n", encoding="utf-8")
        return rc

    def _launch(self, binary: Path) -> None:
        rc = self._torrc(binary)
        self.log.clear()
        self._ready.clear()
        self.progress, self.phase, self.error, self.mode = 0, "starting", None, "starting"
        self.started_at = time.time()
        self.proc = subprocess.Popen([str(binary), "-f", str(rc)], stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                     stdin=subprocess.DEVNULL, text=True, encoding="utf-8", errors="replace",
                                     env=self._env(binary), cwd=str(binary.parent), **self._popen_flags())
        logger.info("started tor (pid %s) from %s", self.proc.pid, binary)
        threading.Thread(target=self._read, args=(self.proc,), daemon=True, name="tor-log").start()

    def _read(self, proc: subprocess.Popen) -> None:
        for line in proc.stdout:  # type: ignore[union-attr]
            line = line.rstrip()
            if not line:
                continue
            self.log.append(line)
            m = _BOOT.search(line)
            if m:
                self.progress = int(m.group(1))
                self.phase = (m.group(3) or m.group(2) or "").strip()
                if self.progress >= 100:
                    self.mode = "ready"
                    self._ready.set()
                    self._invalidate()
                    logger.info("tor bootstrapped 100%%")
            elif "[err]" in line or ("[warn]" in line and "Could not bind" in line):
                self.error = line.split("]", 1)[-1].strip()[:300]
        code = proc.wait()
        if self.proc is proc and self.mode != "stopped":
            self.mode = "error"
            self.error = self.error or f"tor exited (code {code})"
            self._ready.clear()
            self._invalidate()
            logger.warning("tor exited with code %s", code)

    # -------------------------------------------------------------------- stop
    def stop(self) -> dict:
        with self._lock:
            proc, self.proc = self.proc, None
            if proc and proc.poll() is None:
                self.mode = "stopped"
                proc.terminate()
                try:
                    proc.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    proc.kill()
            elif self.mode == "external":
                self.mode = "idle"
            self.progress, self.phase = 0, ""
            self._ready.clear()
            self._invalidate()
            return self.status()

    def wait_ready(self, timeout: float = 120) -> bool:
        if self._ready.is_set():
            return True
        if not self.running:
            return False
        return self._ready.wait(timeout)

    @staticmethod
    def _invalidate() -> None:
        from . import tor_client
        tor_client._tor_cache["ts"] = 0

    def autostart(self) -> None:
        """Called on start-up (non-blocking)."""
        if not settings.TOR_ENABLED or settings.TOR_MANAGED == "never":
            return
        if settings.TOR_MANAGED == "manual":
            self._adopt_external()
            return
        threading.Thread(target=self.start, daemon=True, name="tor-autostart").start()


manager = TorManager()
