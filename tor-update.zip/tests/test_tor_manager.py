import os
import socket
import sys
import time

import pytest

from config.settings import settings
from darkweb_monitor.crawler import tor_manager as tm

pytestmark = pytest.mark.skipif(os.name == "nt", reason="fake tor is a shell-less python script")

FAKE_TOR = """#!{py}
import sys, time
if "--hash-password" in sys.argv:
    print("16:" + "A" * 58)
    sys.exit(0)
rc = open(sys.argv[sys.argv.index("-f") + 1]).read()
assert "SocksPort 127.0.0.1:" in rc and "__OwningControllerProcess" in rc
for p, what in ((0, "starting"), (10, "conn_done"), (50, "loading_descriptors"), (100, "done")):
    print(f"Nov 23 12:00:00.000 [notice] Bootstrapped {{p}}% ({{what}}): {{what}}", flush=True)
    time.sleep(0.05)
time.sleep(60)
"""


def _free_port() -> int:
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    return port


@pytest.fixture
def fake_tor(tmp_path, monkeypatch):
    exe = tmp_path / "tor"
    exe.write_text(FAKE_TOR.format(py=sys.executable))
    exe.chmod(0o755)
    monkeypatch.setattr(settings, "TOR_BINARY", str(exe))
    monkeypatch.setattr(settings, "TOR_PROXY_PORT", _free_port())
    monkeypatch.setattr(settings, "TOR_CONTROL_PORT", _free_port())
    monkeypatch.setattr(settings, "TOR_CONTROL_PASSWORD", "")
    monkeypatch.setattr(tm, "DATA_DIR", tmp_path / "data")
    monkeypatch.setattr(tm, "TOR_BROWSER_PORT", _free_port())  # never adopt a real Tor Browser in tests
    m = tm.TorManager()
    yield m
    m.stop()


def test_start_bootstrap_and_stop(fake_tor):
    st = fake_tor.start()
    assert st["mode"] == "starting" and st["running"]
    assert fake_tor.wait_ready(timeout=10)
    st = fake_tor.status()
    assert st["mode"] == "ready" and st["progress"] == 100
    assert any("Bootstrapped 100%" in x for x in st["log"])
    assert settings.TOR_CONTROL_PASSWORD  # random control password kept in memory
    rc = (tm.DATA_DIR / "tor" / "torrc").read_text()
    assert "HashedControlPassword 16:" in rc and settings.TOR_CONTROL_PASSWORD not in rc
    st = fake_tor.stop()
    assert st["mode"] == "stopped" and not st["running"]


def test_adopts_running_tor(fake_tor):
    srv = socket.socket()
    srv.bind(("127.0.0.1", settings.TOR_PROXY_PORT))
    srv.listen()
    try:
        st = fake_tor.start()
        assert st["mode"] == "external" and not st["running"]
        assert fake_tor.wait_ready(timeout=1)
    finally:
        srv.close()


def test_missing_binary(fake_tor, monkeypatch):
    monkeypatch.setattr(tm, "find_binary", lambda: None)
    st = fake_tor.start()
    assert st["mode"] == "error" and "not found" in st["error"]


def test_process_exit_is_reported(fake_tor, tmp_path, monkeypatch):
    bad = tmp_path / "badtor"
    bad.write_text(f"#!{sys.executable}\nimport sys\nprint('[err] Could not bind to 127.0.0.1')\nsys.exit(1)\n")
    bad.chmod(0o755)
    monkeypatch.setattr(settings, "TOR_BINARY", str(bad))
    fake_tor.start()
    for _ in range(50):
        if fake_tor.mode == "error":
            break
        time.sleep(0.1)
    assert fake_tor.mode == "error" and "Could not bind" in (fake_tor.error or "")


def test_api_endpoints():
    from fastapi.testclient import TestClient

    from darkweb_monitor.api.main import app
    with TestClient(app) as c:
        st = c.get("/api/tor").json()
        assert "mode" in st and "binary" in st
        assert "managed" in c.get("/api/status").json()["tor"]
