"""Start the freshly built bundle like a double-click and check that it works.

    python packaging/smoke_test.py

Checks: the dashboard answers, the bundled Tor is found, and Tor actually starts
(its shared libraries load and it begins bootstrapping). Used by the release workflow.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
APP = ROOT / "build" / "dist" / "DarkWebMonitor"
EXE = APP / ("DarkWebMonitor.exe" if os.name == "nt" else "DarkWebMonitor")
BASE = "http://127.0.0.1:8765"


def call(path: str, method: str = "GET"):
    req = urllib.request.Request(BASE + path, method=method, data=b"{}" if method == "POST" else None,
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=10) as r:
        body = r.read()
        return json.loads(body) if r.headers.get_content_type() == "application/json" else body


def main() -> int:
    data = tempfile.mkdtemp(prefix="dwm-smoke-")
    env = dict(os.environ, DWM_DATA_DIR=data, DWM_NO_BROWSER="1", API_PORT="8765", SCHEDULER_ENABLED="false")
    proc = subprocess.Popen([str(EXE)], cwd=str(APP), env=env, stdin=subprocess.PIPE,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    ok = False
    try:
        for _ in range(90):
            if proc.poll() is not None:
                break
            try:
                html = call("/")
                ok = b"DarkWeb Monitor" in html
                break
            except Exception:  # noqa: BLE001
                time.sleep(1)
        if not ok:
            raise SystemExit("dashboard did not start")
        print("dashboard OK")
        tor = call("/api/tor")
        print("tor:", {k: tor[k] for k in ("mode", "binary", "bundled")})
        if not tor.get("bundled"):
            raise SystemExit("bundled Tor not found")
        for _ in range(90):  # auto-start runs in the background
            tor = call("/api/tor")
            if tor["mode"] in ("ready", "external") or tor["progress"] >= 5:
                break
            if tor["mode"] == "error":
                break
            time.sleep(1)
        print("tor:", tor["mode"], tor["progress"], tor.get("phase"), tor.get("error"))
        print("\n".join(tor.get("log") or []))
        if tor["mode"] == "error" or (tor["mode"] == "starting" and tor["progress"] < 5):
            raise SystemExit("bundled Tor did not start")
        print("tor OK")
        call("/api/tor/stop", "POST")
        return 0
    finally:
        proc.terminate()
        try:
            out, _ = proc.communicate(timeout=20)
        except subprocess.TimeoutExpired:
            proc.kill()
            out, _ = proc.communicate()
        if not ok:
            print(out)


if __name__ == "__main__":
    sys.exit(main())
