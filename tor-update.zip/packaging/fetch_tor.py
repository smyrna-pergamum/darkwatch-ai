"""Download and verify the official Tor Expert Bundle for the current platform.

    python packaging/fetch_tor.py            -> build/tor-bundle/{tor,data}/...

* version: newest stable release listed on dist.torproject.org (or TOR_BUNDLE_VERSION)
* integrity: the bundle's SHA-256 must match ``sha256sums-signed-build.txt`` and that
  file's OpenPGP signature must verify against the Tor Browser signing key below.
  Set TOR_SKIP_GPG=1 only for local experiments (the release workflow never does).

Tor is free software under the 3-clause BSD license (https://www.torproject.org).
"""
from __future__ import annotations

import hashlib
import io
import os
import platform
import re
import shutil
import subprocess
import sys
import tarfile
import tempfile
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "build" / "tor-bundle"
DIST = "https://dist.torproject.org/torbrowser/"
# Tor Browser Developers (signing key) - https://support.torproject.org/tbb/how-to-verify-signature/
SIGNING_KEY = "EF6E286DDA85EA2A4BA7DE684E2C6E8793298290"
KEY_URLS = [f"https://keys.openpgp.org/vks/v1/by-fingerprint/{SIGNING_KEY}",
            f"https://keyserver.ubuntu.com/pks/lookup?op=get&search=0x{SIGNING_KEY}"]


def _get(url: str) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": "darkweb-monitor-build"})
    with urllib.request.urlopen(req, timeout=120) as r:
        return r.read()


def platform_key() -> str:
    osname = {"Windows": "windows", "Darwin": "macos", "Linux": "linux"}[platform.system()]
    arch = platform.machine().lower()
    arch = {"amd64": "x86_64", "x86_64": "x86_64", "arm64": "aarch64", "aarch64": "aarch64"}.get(arch, arch)
    return f"{osname}-{arch}"


def latest_version() -> str:
    html = _get(DIST).decode("utf-8", "replace")
    versions = set(re.findall(r'href="(\d+(?:\.\d+)+)/"', html))  # stable only (no "a" alpha suffix)
    if not versions:
        raise SystemExit("no Tor Browser versions found on " + DIST)
    return max(versions, key=lambda v: tuple(int(x) for x in v.split(".")))


def verify_signature(sums: bytes, sig: bytes) -> None:
    if os.environ.get("TOR_SKIP_GPG") == "1":
        print("WARNING: TOR_SKIP_GPG=1 - signature not checked")
        return
    if not shutil.which("gpg"):
        raise SystemExit("gpg is required to verify the Tor bundle (or set TOR_SKIP_GPG=1 for local tests)")
    with tempfile.TemporaryDirectory() as home:
        key = None
        for u in KEY_URLS:
            try:
                key = _get(u)
                break
            except Exception as e:  # noqa: BLE001
                print("key download failed:", u, e)
        if not key:
            raise SystemExit("could not download the Tor Browser signing key")
        hd = Path(home).as_posix()  # forward slashes also work for the MSYS gpg on Windows runners
        gpg = ["gpg", "--batch", "--homedir", hd]
        subprocess.run(gpg + ["--import"], input=key, check=True, capture_output=True)
        s, d = Path(home) / "sums.txt", Path(home) / "sums.txt.asc"
        s.write_bytes(sums)
        d.write_bytes(sig)
        r = subprocess.run(gpg + ["--status-fd", "1", "--verify", d.as_posix(), s.as_posix()],
                           capture_output=True, text=True)
        ok = any(line.startswith("[GNUPG:] VALIDSIG") and SIGNING_KEY in line.replace(" ", "")
                 for line in r.stdout.splitlines())
        if not ok:
            print(r.stdout, r.stderr)
            raise SystemExit("signature of sha256sums-signed-build.txt did NOT verify")
    print("signature OK (Tor Browser Developers", SIGNING_KEY + ")")


def main() -> int:
    key = platform_key()
    version = os.environ.get("TOR_BUNDLE_VERSION") or latest_version()
    name = f"tor-expert-bundle-{key}-{version}.tar.gz"
    base = f"{DIST}{version}/"
    print("Tor Expert Bundle", version, "for", key)
    sums = _get(base + "sha256sums-signed-build.txt")
    verify_signature(sums, _get(base + "sha256sums-signed-build.txt.asc"))
    expected = next((ln.split()[0] for ln in sums.decode().splitlines() if ln.strip().endswith(name)), None)
    if not expected:
        raise SystemExit(f"{name} is not listed in sha256sums-signed-build.txt")
    blob = _get(base + name)
    got = hashlib.sha256(blob).hexdigest()
    if got != expected:
        raise SystemExit(f"SHA-256 mismatch for {name}: {got} != {expected}")
    print("sha256 OK", got)
    shutil.rmtree(OUT, ignore_errors=True)
    OUT.mkdir(parents=True)
    with tarfile.open(fileobj=io.BytesIO(blob), mode="r:gz") as tf:
        if sys.version_info >= (3, 12):
            tf.extractall(OUT, filter="data")
        else:  # pragma: no cover
            for m in tf.getmembers():
                if m.name.startswith(("/", "..")) or ".." in Path(m.name).parts:
                    raise SystemExit("unsafe path in archive: " + m.name)
            tf.extractall(OUT)
    exe = OUT / "tor" / ("tor.exe" if os.name == "nt" else "tor")
    if not exe.is_file():
        raise SystemExit(f"tor binary missing after extraction: {exe}")
    if os.name != "nt":
        exe.chmod(0o755)
    (OUT / "TOR_NOTICE.txt").write_text(
        f"Tor Expert Bundle {version} ({key}) from {base}{name}\nSHA-256 {got}\n\n"
        "Tor is free software by The Tor Project, Inc., distributed under the 3-clause BSD license.\n"
        "Source code and license: https://gitlab.torproject.org/tpo/core/tor\n", encoding="utf-8")
    print("extracted to", OUT)
    return 0


if __name__ == "__main__":
    sys.exit(main())
